# Sport Science Report Generator - Netlify Deployment Guide

## Overview

This is a React + Netlify Functions application for generating comprehensive pre-post sport science analysis reports. Students upload a CSV, the tool calculates statistics (Cohen's d, RCI, Bayes Factors, CV%), and generates HTML and JSON reports.

---

## Project Structure

```
sport-science-report-generator/
├── netlify.toml                 # Netlify configuration
├── package.json                 # Dependencies
├── vite.config.js              # Vite build config
├── index.html                  # React entry point
├── src/
│   ├── App.jsx                 # Main React component
│   ├── App.css                 # Styling
│   └── main.jsx                # React DOM render
├── netlify/functions/
│   └── generate-report.mjs      # Serverless function
└── README.md
```

---

## Setup & Local Development

### 1. Prerequisites

- Node.js 16+ (https://nodejs.org/)
- npm or yarn
- Git (for version control)

### 2. Clone or Create the Project

```bash
# Create new directory
mkdir sport-science-reports
cd sport-science-reports

# Initialize git
git init

# Copy files from this guide into the directory
# (App.jsx, App.css, package.json, netlify.toml, etc.)
```

### 3. Install Dependencies

```bash
npm install
```

### 4. Run Locally

```bash
# Start the dev server
npm run dev

# In another terminal, serve Netlify functions locally
netlify dev
```

The app will run at `http://localhost:3000` (or the port shown by vite).

### 5. Test with Sample CSV

Create `sample.csv`:

```csv
athlete_id,athlete_name,test_date,session_type,test_name,result
001,Alice,2026-05-10,pre,CMJ_Height,45.2
001,Alice,2026-05-10,pre,CMJ_Height,46.1
001,Alice,2026-05-10,pre,CMJ_Height,45.8
001,Alice,2026-05-10,pre,Speed_10m,1.82
001,Alice,2026-05-10,pre,Speed_10m,1.80
001,Alice,2026-07-15,post,CMJ_Height,48.5
001,Alice,2026-07-15,post,CMJ_Height,49.2
001,Alice,2026-07-15,post,CMJ_Height,48.9
001,Alice,2026-07-15,post,Speed_10m,1.75
001,Alice,2026-07-15,post,Speed_10m,1.77
002,Bob,2026-05-10,pre,CMJ_Height,42.3
002,Bob,2026-05-10,pre,CMJ_Height,43.1
002,Bob,2026-05-10,pre,CMJ_Height,42.8
002,Bob,2026-07-15,post,CMJ_Height,44.2
002,Bob,2026-07-15,post,CMJ_Height,45.1
002,Bob,2026-07-15,post,CMJ_Height,44.5
```

Upload via the UI and check that reports generate.

---

## Deployment to Netlify

### Option 1: Connect GitHub Repository (Recommended)

1. **Push code to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit: Sport Science Report Generator"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/sport-science-reports
   git push -u origin main
   ```

2. **Log in to Netlify**
   - Go to https://netlify.com
   - Click "Sign up" → use GitHub auth

3. **Create New Site from Git**
   - Click "Add new site" → "Import an existing project"
   - Select GitHub, then your repository
   - Build settings:
     - **Build command:** `npm run build`
     - **Publish directory:** `dist`
     - **Functions directory:** `netlify/functions`
   - Click "Deploy"

Netlify will automatically redeploy whenever you push to GitHub.

### Option 2: Manual Deploy (Drag & Drop)

1. **Build locally**
   ```bash
   npm run build
   ```

2. **Drag the `dist` folder** to https://app.netlify.com/drop

---

## Environment Variables (if needed later)

If you add backend services, create a `.env.local` file:

```
VITE_API_URL=https://your-api.com
```

Reference in React:
```javascript
const apiUrl = import.meta.env.VITE_API_URL;
```

---

## CSV Format Requirements

Your CSV must have these columns (order doesn't matter):

- `athlete_id` - Unique identifier (string or number)
- `athlete_name` - Athlete's name
- `test_date` - Date of test (YYYY-MM-DD recommended, not strictly enforced)
- `session_type` - Either "pre" or "post"
- `test_name` - Name of test (e.g., "CMJ_Height", "Speed_10m")
- `result` - Numeric result value

**Important:**
- One row per trial
- Multiple trials for same athlete/test/session = multiple rows
- No missing values in the `result` column

Example:
```csv
athlete_id,athlete_name,test_date,session_type,test_name,result
001,Alice,2026-05-10,pre,CMJ_Height,45.2
001,Alice,2026-05-10,pre,CMJ_Height,46.1
```

---

## Features & Calculations

### Per-Athlete Metrics

- **Mean ± SD** for pre and post
- **CV%** (coefficient of variation) per session
- **Change** (raw and %)
- **Cohen's d** (effect size)
- **95% Confidence Interval** on change
- **Reliable Change Index (RCI)** - identifies true change vs. noise
- **Bayes Factor** - evidence for/against improvement
- **Squad Mean CV%** - how variable the test is across all athletes

### Report Outputs

- **HTML Report** - Professional summary table, downloadable
- **JSON Export** - Raw data for further analysis
- **On-screen cards** - Expandable athlete-by-athlete view

---

## Customization

### Adding New Derived Metrics

Edit the backend function to calculate:
- **Anaerobic Speed Reserve (ASR)** = Max Speed - 10m Speed
- **Modified 505** = 10m Sprint - 505 Time
- **Sprint Reserve Ratio** = (Max Speed - 10m Speed) / Max Speed

Example in function:
```javascript
if ('Max_Speed' in athlete.tests && 'Speed_10m' in athlete.tests) {
  const asr = meanMaxSpeed - mean10mSpeed;
  report.derived_metrics.ASR = asr;
}
```

### Adding Test Presets

In `App.jsx`, expand `COMMON_TESTS` array:
```javascript
const COMMON_TESTS = [
  'CMJ_Height',
  'CMJ_Force',
  'Your_New_Test',
  // ... etc
];
```

### Changing Report Template

The HTML export is generated in the `generateHTMLReport()` function in `App.jsx`. Modify the template to change styling or add sections.

---

## Troubleshooting

### "Function returned invalid status 400"

- Check CSV format (required columns?)
- Ensure `result` column has numbers only
- Check for blank rows at end of CSV

### Netlify Deploy Fails

```bash
# Check build locally
npm run build

# Check for errors
npm run dev
```

Common issues:
- Missing dependencies in `package.json`
- Syntax errors in React code
- Node version mismatch (use Node 16+)

### Reports Don't Calculate

- Verify CSV has both "pre" and "post" session_type entries
- Check that test names match exactly (case-sensitive)

---

## Advanced Deployment Options

### Option A: Deploy with Backend Service

If you want to use Python for more advanced stats (Bayesian analysis, ML), consider:

1. **Separate backend** on Heroku, Railway, or AWS Lambda
2. Frontend calls backend API
3. Netlify hosts frontend only

### Option B: GitHub Actions + Deployment Secrets

Automate deployment on push:

Create `.github/workflows/deploy.yml`:
```yaml
name: Deploy
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
      - run: npm install && npm run build
      - uses: netlify/actions/cli@master
        env:
          NETLIFY_AUTH_TOKEN: ${{ secrets.NETLIFY_AUTH_TOKEN }}
          NETLIFY_SITE_ID: ${{ secrets.NETLIFY_SITE_ID }}
```

---

## Contact & Support

- **React Docs:** https://react.dev
- **Netlify Docs:** https://docs.netlify.com
- **Vite Docs:** https://vitejs.dev

---

## License & Attribution

This tool is designed for sport science education. Freely modify and share.

**Citations for stats:**
- Cohen, J. (1988). Statistical power analysis for the behavioral sciences. Lawrence Erlbaum.
- Jacobson, N. S., & Truax, P. (1991). Clinical significance. Behavior Therapy, 22(4), 629–642.
