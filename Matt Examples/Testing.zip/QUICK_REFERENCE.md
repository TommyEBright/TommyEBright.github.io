# Sport Science Report Generator - Quick Reference

## CSV Format Checklist

✅ **Required Columns (exact names):**
```
athlete_id, athlete_name, test_date, session_type, test_name, result
```

✅ **Column Rules:**
- `athlete_id` = unique ID (string or number)
- `athlete_name` = athlete's name
- `test_date` = date (any format)
- `session_type` = **"pre"** or **"post"** (lowercase, exact match)
- `test_name` = exact test name (e.g., "CMJ_Height", "Speed_10m")
- `result` = **numeric only** (no text, no units)

✅ **Row Rules:**
- One row per trial
- Multiple trials = multiple rows (same athlete, test, session)
- No blank rows at end
- No missing values in `result` column

❌ **Common Mistakes:**
- Space in session_type: "Pre" ❌ (use "pre")
- Units in result: "45.2cm" ❌ (use 45.2)
- Only one trial per session ❌ (use multiple for better CV%)
- Mismatched test names: "CMJ_Height" vs "CMJ_height" ❌

---

## CSV Example

**Correct format:**
```csv
athlete_id,athlete_name,test_date,session_type,test_name,result
001,Alice Smith,2026-05-10,pre,CMJ_Height,45.2
001,Alice Smith,2026-05-10,pre,CMJ_Height,46.1
001,Alice Smith,2026-05-10,pre,CMJ_Height,45.8
001,Alice Smith,2026-05-10,pre,Speed_10m,1.82
001,Alice Smith,2026-05-10,pre,Speed_10m,1.80
001,Alice Smith,2026-07-15,post,CMJ_Height,48.5
001,Alice Smith,2026-07-15,post,CMJ_Height,49.2
001,Alice Smith,2026-07-15,post,CMJ_Height,48.9
001,Alice Smith,2026-07-15,post,Speed_10m,1.75
001,Alice Smith,2026-07-15,post,Speed_10m,1.77
```

---

## Understanding Your Results

### Pre & Post (Mean ± SD)
**Example:** Pre: 45.7 ± 0.4  |  Post: 48.9 ± 0.4

- Shows average score and variability
- SD = standard deviation (spread of trials)
- Compare visually: higher is better for most tests

### CV% (Coefficient of Variation)
**Range:** 0–50%

- **< 5%** = Excellent consistency ⭐⭐⭐
- **5–10%** = Good consistency ⭐⭐
- **10–15%** = Fair consistency ⭐
- **> 15%** = High variability ⚠️

**What it means:** How consistent trials are. Athlete with CV% 3% is more reliable than CV% 12%.

### Change (Raw + %)
**Example:** +3.2 cm (+7.0%)

- Raw change = Post - Pre
- Percent change = (change / pre) × 100
- Positive = improvement, Negative = decline

### Cohen's d (Effect Size)
**Range:** -∞ to +∞ (typically -2 to +2)

| Value | Interpretation |
|-------|-----------------|
| < 0.2 | Negligible ➡️ Almost no real change |
| 0.2–0.5 | Small 📈 Noticeable but small |
| 0.5–0.8 | Medium 📈📈 Clear, meaningful change |
| > 0.8 | Large 📈📈📈 Substantial improvement |

**Example:** d = 1.24 (Large effect) = solid improvement

### 95% CI (Confidence Interval)
**Example:** [+2.1 cm, +4.3 cm]

- Range where "true" change likely sits
- Wider interval = less certain
- Narrower interval = more certain
- If spans zero = uncertain if real change

### RCI (Reliable Change Index)
**Example:** RCI = 2.8  ✓ Reliable

| Value | Meaning |
|-------|---------|
| \|RCI\| > 1.96 | ✓ Reliable change (exceeds noise) |
| \|RCI\| < 1.96 | ✗ Not reliable (could be noise) |

**Example:** RCI = 0.4 (✗) = change might just be normal fluctuation

### Bayes Factor (BF₁₀)
**Example:** BF = 12.5  →  "Strong evidence for improvement"

| BF Value | Evidence |
|----------|----------|
| > 10 | **Strong** 🎯 Very confident in improvement |
| 3–10 | **Moderate** ✓ Good evidence for improvement |
| 1–3 | **Weak** ~ Some evidence, but not conclusive |
| 0.33–1 | **Weak** ~ Leaning toward no change |
| 0.1–0.33 | **Moderate** ✗ Good evidence against change |
| < 0.1 | **Strong** ❌ Very confident: no real change |

**Plain English:** BF = 10 means "10× more likely to see this result if there WAS improvement than if there WASN'T"

### Squad CV Mean
**Example:** 8.5%

- Average CV% across all athletes for that test
- Tells you how variable the test is
- High value = test is inherently noisy
- Use to benchmark individual athletes

---

## How to Use the Report

### 1. **Identify Top Performers**
Look for athletes with:
- ✓ Large Cohen's d (> 0.8)
- ✓ High Bayes Factor (BF > 10)
- ✓ Positive % change

### 2. **Flag Non-Responders**
Look for:
- ✗ Bayes Factor < 0.5 (no improvement)
- ✗ Percent change < 3% (minimal change)
- ✗ RCI not reliable (✗ mark)

### 3. **Assess Reliability**
Check:
- CV% < 10% = trustworthy result
- CV% > 15% = be skeptical, might be noise
- Low RCI = "could be just noise"

### 4. **Compare Athletes**
Use Cohen's d and BF, not raw numbers:
- Alice: d = 1.2, BF = 15 → **Strong improvement**
- Bob: d = 0.3, BF = 0.8 → **No clear improvement**

---

## Test Name Reference

### Speed & Sprint
- `Speed_10m` - Time to 10 meters
- `Speed_20m` - Time to 20 meters
- `Speed_30m` - Time to 30 meters
- `Max_Speed` - Peak speed (from GPS/timing)
- `Sprint_Acceleration` - Acceleration phase (e.g., 0–5m)

### Jump & Power
- `CMJ_Height` - Countermovement jump height
- `CMJ_Force` - Peak force during jump
- `Broad_Jump` - Horizontal jump distance
- `Triple_Hop_Distance` - Triple hop length
- `Countermovement_Jump_Power` - Power output

### Strength
- `Squat_1RM` - One-rep max squat
- `Bench_Press_1RM` - One-rep max bench
- `Deadlift_1RM` - One-rep max deadlift
- `Hand_Grip_Strength` - Grip force

### Agility & Coordination
- `Modified_505` - 505 agility test (modified version)
- `Agility_T_Test` - T-test agility
- `Illinois_Agility_Test` - Illinois agility test
- `Shuttle_Run` - Shuttle sprint time

### Endurance
- `Yo_Yo_IR1` - Yo-Yo intermittent recovery level 1
- `Yo_Yo_IR2` - Yo-Yo intermittent recovery level 2
- `MLSS_Speed` - Speed at maximal lactate steady state
- `Lactate_Threshold_Speed` - Speed at lactate threshold
- `V02_Max` - Maximum oxygen uptake

---

## Tips for Best Results

✅ **Use 3+ trials per session**
- Gives better estimate of true performance
- Improves CV% accuracy
- Reduces noise

✅ **Same tester, same conditions**
- Consistent surface, time of day, warm-up
- Reduces environmental noise

✅ **Use consistent test names**
- Check spelling exactly
- Case-sensitive: "CMJ_Height" ≠ "cmj_height"

✅ **Have both pre and post data**
- Report only appears for pre-post pairs
- Minimum 3–4 weeks apart is ideal

❌ **Avoid:**
- Single trial per session (too noisy)
- Different testers (increases variability)
- Inconsistent conditions (environmental noise)
- Mixing different test protocols

---

## Download & Share

**HTML Report**
- Right-click → "Save as" to save locally
- Share with coaches, athletes, parents
- Professional formatting, print-friendly

**JSON Export**
- Import into Excel for custom analysis
- Share raw data with collaborators
- Use for meta-analysis or publication

---

## Common Questions

**Q: What if Cohen's d is negative?**
A: Means the athlete got worse (post < pre). Can still be reliable if BF is strong.

**Q: Can I mix different tests in one report?**
A: Yes! Upload all tests at once; they'll be sorted by athlete.

**Q: Why doesn't my test show up?**
A: Likely missing either pre OR post data. Both required.

**Q: How many athletes can I upload?**
A: ~100 athletes, unlimited tests. For >500 athletes, split into batches.

**Q: Can I use this for homework/assignment?**
A: Yes! This tool is designed for student learning.

**Q: Can I compare to norms/baselines?**
A: Not yet. Future version will add reference cohorts.

---

## Getting Help

1. **Check CSV format** - Most issues are CSV-related
2. **Read the README** - Full documentation
3. **Look at sample.csv** - Example of correct format
4. **Check browser console** - F12 → Console tab for errors

---

## Need to Report an Issue?

Check:
- ✓ CSV has all required columns
- ✓ No blank rows at end
- ✓ Result column is numeric only
- ✓ session_type is "pre" or "post" (lowercase)
- ✓ Athlete has both pre AND post data

If still stuck, share your CSV (remove sensitive info) with the developer.

---

**Ready to analyze? Upload your CSV and generate your first report!** 📊
