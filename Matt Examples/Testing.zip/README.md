# Sport Science Report Generator

A **student-friendly web application** for generating pre-post sport science analysis reports. Upload a CSV of test results, get back professional reports with statistics, effect sizes, and Bayes Factors.

![Sport Science Report Generator](https://via.placeholder.com/1200x600)

---

## Features

✨ **Simple CSV Upload**
- Drag & drop or click to upload
- Auto-detects test types and athletes

📊 **Comprehensive Statistics**
- **Means ± SD** for pre and post sessions
- **Coefficient of Variation (CV%)** - trial-to-trial variability
- **Cohen's d** - effect size interpretation
- **95% Confidence Intervals** - uncertainty in change
- **Reliable Change Index (RCI)** - true change vs. measurement noise
- **Bayes Factor** - evidence for/against improvement
- **Squad mean CV%** - consistency across athletes

📈 **Flexible Test Options**
- 30+ common tests (CMJ, sprint, strength, endurance)
- Support for multiple trials per test
- Pre-post or single-session analysis
- Automatic calculation of derived metrics (ASR, sprint reserve ratio)

💾 **Export Options**
- **HTML Report** - professional summary table
- **JSON Export** - raw data for Excel/R analysis

🎯 **Student-Friendly**
- No statistical background required
- Clear interpretation of effect sizes and Bayes Factors
- Responsive design (works on tablet/phone)

---

## Quick Start

### 1. Prepare Your CSV

Required columns:
```
athlete_id, athlete_name, test_date, session_type, test_name, result
```

Example:
```csv
001, Alice, 2026-05-10, pre, CMJ_Height, 45.2
001, Alice, 2026-05-10, pre, CMJ_Height, 46.1
001, Alice, 2026-05-10, pre, Speed_10m, 1.82
001, Alice, 2026-07-15, post, CMJ_Height, 48.5
001, Alice, 2026-07-15, post, CMJ_Height, 49.2
001, Alice, 2026-07-15, post, Speed_10m, 1.75
```

**Key points:**
- Multiple trials = multiple rows (same athlete/test/session)
- `session_type` is either "pre" or "post"
- `result` must be numeric

### 2. Upload & Generate

1. Open [Live App](https://yourapp.netlify.app) (replace with your URL)
2. Drag CSV file or click to select
3. Click "Generate Report"
4. View results on screen or download

### 3. Interpret Results

**Cohen's d interpretation:**
- < 0.2 = Negligible
- 0.2–0.5 = Small
- 0.5–0.8 = Medium
- > 0.8 = Large

**Bayes Factor (BF₁₀) interpretation:**
- BF > 10 = Strong evidence for change
- BF 3–10 = Moderate evidence for change
- BF 0.33–3 = Inconclusive
- BF < 0.33 = Evidence against change

**Reliable Change Index (RCI):**
- |RCI| > 1.96 = Reliable change (exceeds measurement error)
- |RCI| < 1.96 = Not reliable (could be noise)

---

## Local Development

### Prerequisites
- Node.js 16+
- npm or yarn

### Setup

```bash
# Install dependencies
npm install

# Run locally
npm run dev

# Build for production
npm run build
```

Visit `http://localhost:3000`.

---

## Deployment to Netlify

### Option 1: GitHub + Netlify (Recommended)

1. Push to GitHub:
   ```bash
   git add .
   git commit -m "Sport Science Report Generator"
   git push origin main
   ```

2. Log in to Netlify.com → Connect GitHub repo
3. Build settings:
   - Command: `npm run build`
   - Publish: `dist`
   - Functions: `netlify/functions`

Netlify auto-deploys on push to main.

### Option 2: Netlify CLI

```bash
# Install
npm install -g netlify-cli

# Deploy
netlify deploy --prod
```

---

## CSV Format Details

### Valid Column Names (exact, case-sensitive)
- `athlete_id` (string or number)
- `athlete_name` (string)
- `test_date` (any format; not strictly validated)
- `session_type` (must be "pre" or "post")
- `test_name` (exact match required for grouping)
- `result` (numeric only)

### Common Test Names
```
CMJ_Height               Agility_T_Test
CMJ_Force               Illinois_Agility_Test
Speed_10m               Shuttle_Run
Speed_20m               Triple_Hop_Distance
Speed_30m               Single_Leg_Hop_Distance
Max_Speed               Medicine_Ball_Throw
Modified_505            Vertical_Reach
Sprint_Acceleration     Sit_and_Reach
Squat_1RM               Hand_Grip_Strength
Bench_Press_1RM         Reactive_Strength_Index
Deadlift_1RM            MLSS_Speed
Broad_Jump              Lactate_Threshold_Speed
Yo_Yo_IR1               V02_Max
Yo_Yo_IR2               
```

You can use any test name; these are just examples.

---

## Derived Metrics (Automatic)

If your CSV includes the right tests, the tool calculates:

- **Anaerobic Speed Reserve (ASR)** = Max_Speed − Speed_10m
- **Modified 505 Derived** = Speed_10m − Modified_505
- **Sprint Reserve Ratio** = (Max_Speed − Speed_10m) / Max_Speed

---

## Statistics Explained

### Coefficient of Variation (CV%)
**Formula:** `(SD / Mean) × 100`
- Tells you trial-to-trial consistency
- CV% < 5% = very consistent
- CV% 5–10% = good consistency
- CV% > 10% = high variability

**Use case:** Flag athletes with inconsistent technique.

### Cohen's d
**Formula:** `(Mean_Post − Mean_Pre) / Pooled_SD`
- Standardized effect size (unit-free)
- Comparable across different tests
- Positive = improvement, Negative = decline

### Reliable Change Index (RCI)
**Formula:** `Change / Measurement_Error`
- Accounts for test-retest reliability
- Assumes CV% captures measurement error
- RCI > 1.96 = statistically reliable change

### Bayes Factor
**Interpretation:**
- Compares evidence for H1 (change) vs. H0 (no change)
- BF = 10 means 10× more likely given improvement than no change
- Student-friendly: no p-values, no "significance thresholds"

---

## Troubleshooting

### "CSV validation failed"
- Check all required columns present
- Verify `result` column is numeric (no text)
- No blank rows at end

### "No pre-post pairs found"
- Ensure `session_type` is exactly "pre" or "post" (lowercase)
- Verify athlete has both pre AND post data
- Check test names match exactly

### Slow upload / timeout
- Very large CSVs (>100 athletes, >1000 rows) might timeout
- Split into smaller batches if needed

### Netlify function returns 500 error
- Check browser console (F12 → Network tab)
- Try with sample CSV to isolate issue
- Redeploy: `netlify deploy --prod`

---

## Advanced Customization

### Add Python Backend (for Bayesian analysis)

Replace Netlify Function with a Python API:

1. Set up backend on Railway / Heroku
2. Update `fetch()` call in `App.jsx` to point to your API
3. Use `pingouin` + `numpy` for advanced stats

Example backend (Python):
```python
from fastapi import FastAPI
from pingouin import bayesfactor_ttest
import pandas as pd

app = FastAPI()

@app.post("/generate-report")
async def generate_report(csv_data: str):
    df = pd.read_csv(StringIO(csv_data))
    # ... process and return results
```

### Modify Report Template

Edit the `generateHTMLReport()` function in `App.jsx` to:
- Add/remove sections
- Change styling
- Include sport-specific interpretation

### Add Logo & Branding

1. Place logo in `src/logo.png`
2. Update header in `App.jsx`:
   ```jsx
   <img src="/logo.png" alt="Logo" style={{ maxHeight: '50px' }} />
   ```
3. Update CSS colors in `App.css`

---

## Tech Stack

- **Frontend:** React 18 + Vite
- **Styling:** CSS3 (no framework)
- **Backend:** Netlify Functions (Node.js)
- **Stats:** Pingouin.js (approximate Bayes Factors)
- **Hosting:** Netlify

---

## Limitations & Known Issues

⚠️ **Bayes Factor approximation:** Uses t-statistic approximation; for publication-quality results, use R/Python pingouin.

⚠️ **Large CSVs:** Function has ~10-second timeout; >500 athletes might fail.

⚠️ **Mobile:** Works on mobile but best on desktop (larger screen for tables).

---

## Contributing

Want to improve this? Ideas:

- [ ] Add interactive plots (Pre vs. Post scatter)
- [ ] Group analysis (by position, by training block)
- [ ] Athlete ranking / percentile system
- [ ] Integration with training management apps
- [ ] PDF export
- [ ] Database storage of past reports

---

## References

**Statistics:**
- Cohen, J. (1988). Statistical power analysis for the behavioral sciences.
- Jacobson, N. S., & Truax, P. (1991). Clinical significance. *Behavior Therapy*.

**Reliable Change:**
- Wise, E. A. (2004). Methods for analyzing psychotherapy outcomes. *Journal of Personality Assessment*, 82(1), 50–59.

**Sport Science Test Norms:**
- Ellis et al. (2022). Training load and countermovement jump force-time relationships. *IJSPP*.

---

## License

MIT License. Free to use and modify for educational purposes.

---

## Contact

Built for sport science students and practitioners. Questions? Comments? [Open an issue](https://github.com/yourname/sport-science-reports/issues).

---

**Happy reporting! 📊**
